gRPC library for google-iam-v1

grpc-google-iam-v1 is the IDL-derived library for the google-iam (v1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/iam/v1


