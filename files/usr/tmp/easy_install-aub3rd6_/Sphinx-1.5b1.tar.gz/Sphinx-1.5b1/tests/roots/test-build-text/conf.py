master_doc = 'contents'
source_suffix = '.txt'
exclude_patterns = ['_build']
