===========================
Literal Includes for python
===========================

block start with blank or comment
=================================

.. literalinclude:: target.py
   :pyobject: block_start_with_comment

.. literalinclude:: target.py
   :pyobject: block_start_with_blank

