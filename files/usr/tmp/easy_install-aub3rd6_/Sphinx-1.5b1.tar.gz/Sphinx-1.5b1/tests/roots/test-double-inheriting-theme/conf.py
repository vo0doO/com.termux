# -*- coding: utf-8 -*-

import sys, os

templates_path = ['_templates']
master_doc = 'index'
html_theme = 'base_theme2'
exclude_patterns = ['_build']
