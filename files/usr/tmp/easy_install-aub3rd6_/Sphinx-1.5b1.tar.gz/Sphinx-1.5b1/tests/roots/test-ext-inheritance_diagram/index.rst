============================
test-ext-inheritance_diagram
============================

.. inheritance-diagram:: test.Foo

.. inheritance-diagram:: test.Foo
   :caption: Test Foo!
