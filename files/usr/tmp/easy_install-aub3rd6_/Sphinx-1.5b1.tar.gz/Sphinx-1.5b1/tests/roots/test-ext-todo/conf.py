# -*- coding: utf-8 -*-

extensions = ['sphinx.ext.todo']
master_doc = 'index'
