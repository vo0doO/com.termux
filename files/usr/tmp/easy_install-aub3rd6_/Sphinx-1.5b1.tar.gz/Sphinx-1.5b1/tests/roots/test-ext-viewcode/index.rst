viewcode
========

.. py:module:: spam

.. autofunction:: func1

.. autofunction:: func2

.. autofunction:: spam.mod1.func1

.. autofunction:: spam.mod2.func2

.. autofunction:: Class1

.. autofunction:: Class2

.. autofunction:: spam.mod1.Class1

.. autofunction:: spam.mod2.Class2


.. literalinclude:: spam/__init__.py
   :language: python
   :pyobject: func1

.. literalinclude:: spam/mod1.py
   :language: python
   :pyobject: func1


.. toctree::

   objects
