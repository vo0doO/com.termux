bar
===

Same footnote number [1]_ in bar.rst

.. [1] footnote in bar
