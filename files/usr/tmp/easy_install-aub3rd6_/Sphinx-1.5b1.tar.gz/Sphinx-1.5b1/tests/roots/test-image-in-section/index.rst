test-image-in-section
=====================
this is dummy content


|picture| Test section
----------------------
blah blah blah


Another section
---------------
another blah


Other [blah] |picture| section
------------------------------
other blah

|picture|
---------
blah blah blah
